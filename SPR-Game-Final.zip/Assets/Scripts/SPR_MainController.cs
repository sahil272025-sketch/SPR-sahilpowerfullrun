using UnityEngine;
using UnityEngine.UI;

public class SPR_MainController : MonoBehaviour {
    public float speed = 10f;
    public float jumpForce = 15f;
    public bool isSahilHero = true;
    public Text scoreText;
    private float score = 0;

    void Start() {
        if(isSahilHero) {
            speed *= 2;
            jumpForce *= 1.5f;
        }
    }

    void Update() {
        transform.Translate(Vector3.forward * speed * Time.deltaTime);
        score += Time.deltaTime * 10;
        scoreText.text = "Score: " + ((int)score).ToString();
    }

    public void Jump() { }

    public void Slide() { 
        transform.localScale = new Vector3(1f, 0.5f, 1f);
        Invoke("StopSlide", 1.2f);
    }

    void StopSlide() { transform.localScale = Vector3.one; }
}
