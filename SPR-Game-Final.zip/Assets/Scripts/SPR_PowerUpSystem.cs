using UnityEngine;

public class SPR_PowerUpSystem : MonoBehaviour {
    public bool isMagnetActive = false;
    public bool hasShield = false;
    public GameObject greenGlow;

    void Update() {
        if (isMagnetActive) {
            GameObject[] coins = GameObject.FindGameObjectsWithTag("Coin");
            foreach (GameObject coin in coins) {
                if (Vector3.Distance(coin.transform.position, transform.position) < 15f) {
                    coin.transform.position = Vector3.MoveTowards(
                        coin.transform.position,
                        transform.position,
                        20f * Time.deltaTime
                    );
                }
            }
        }
    }

    public void ActivateShield() {
        hasShield = true;
        greenGlow.SetActive(true);
    }
}
