using UnityEngine;
using UnityEngine.UI;

public class SPR_WelcomeUI : MonoBehaviour {
    public Text welcomeText;

    void Start() {
        welcomeText.text = "Welcome to Sahil Powerful Run";
        Invoke("HideText", 5f);
    }

    void HideText() {
        welcomeText.gameObject.SetActive(false);
    }
}
