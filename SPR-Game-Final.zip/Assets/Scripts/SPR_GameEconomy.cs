using UnityEngine;
using UnityEngine.UI;

public class SPR_GameEconomy : MonoBehaviour {
    public int totalCoins;
    public int playerPrice = 5000;
    public Text coinDisplay;

    public void CollectCoin() {
        totalCoins++;
        coinDisplay.text = "Coins: " + totalCoins;
        PlayerPrefs.SetInt("SPR_Coins", totalCoins);
    }

    public void BuyPlayer(int id) {
        if(totalCoins >= playerPrice) {
            totalCoins -= playerPrice;
            PlayerPrefs.SetInt("PlayerUnlocked_" + id, 1);
        }
    }
}
