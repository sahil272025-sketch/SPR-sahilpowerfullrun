using UnityEngine;

public class SPR_AudioManager : MonoBehaviour {
    public AudioSource bgMusic;
    public AudioClip coinSFX;
    public AudioClip jumpSFX;

    void Start() {
        bgMusic.loop = true;
        bgMusic.Play();
    }

    public void PlayJumpSound() {
        bgMusic.PlayOneShot(jumpSFX);
    }
}
