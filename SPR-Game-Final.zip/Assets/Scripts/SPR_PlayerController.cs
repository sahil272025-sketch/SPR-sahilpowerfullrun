using UnityEngine;

public class SPR_PlayerController : MonoBehaviour {
    public float normalSpeed = 8f;
    public float jumpForce = 12f;
    public bool isSahilHero = true; 
    private float currentSpeed;

    void Start() {
        currentSpeed = isSahilHero ? (normalSpeed * 2) : normalSpeed;
        if(isSahilHero) jumpForce *= 1.5f;
    }

    void Update() {
        transform.Translate(Vector3.forward * currentSpeed * Time.deltaTime);
    }

    public void Jump() { }

    public void Slide() { 
        transform.localScale = new Vector3(1f, 0.5f, 1f); 
        Invoke("StopSlide", 1.0f); 
    }

    void StopSlide() { 
        transform.localScale = Vector3.one; 
    }

    public void MoveRight() {
        transform.Translate(Vector3.right * 2f);
    }

    public void MoveLeft() {
        transform.Translate(Vector3.left * 2f);
    }
}
