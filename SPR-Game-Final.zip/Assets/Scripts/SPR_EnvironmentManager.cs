using UnityEngine;

public class SPR_EnvironmentManager : MonoBehaviour {
    public GameObject[] obstacles;
    public GameObject coinPrefab;
    public Transform spawnPoint;

    void Start() {
        InvokeRepeating("SpawnObstacle", 2f, 2f);
    }

    void SpawnObstacle() {
        int random = Random.Range(0, 2);

        if(random == 0) {
            int index = Random.Range(0, obstacles.Length);
            Instantiate(obstacles[index], spawnPoint.position, Quaternion.identity);
        } else {
            Instantiate(coinPrefab, spawnPoint.position, Quaternion.identity);
        }
    }
}
