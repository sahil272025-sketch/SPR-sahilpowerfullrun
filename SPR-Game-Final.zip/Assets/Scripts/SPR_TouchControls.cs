using UnityEngine;

public class SPR_TouchControls : MonoBehaviour {
    private Vector2 startTouch, endTouch;
    public SPR_PlayerController player;

    void Update() {
        if (Input.touchCount > 0) {
            Touch touch = Input.GetTouch(0);

            if (touch.phase == TouchPhase.Began)
                startTouch = touch.position;

            if (touch.phase == TouchPhase.Ended) {
                endTouch = touch.position;
                AnalyzeSwipe();
            }
        }
    }

    void AnalyzeSwipe() {
        float x = endTouch.x - startTouch.x;
        float y = endTouch.y - startTouch.y;

        if (Mathf.Abs(x) > Mathf.Abs(y)) {
            if (x > 0)
                player.SendMessage("MoveRight");
            else
                player.SendMessage("MoveLeft");
        } else {
            if (y > 0)
                player.Jump();
            else
                player.Slide();
        }
    }
}
